package com.entity.layer2;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the LOGIN_DETAILS database table.
 * 
 */
@Entity
@Table(name="LOGIN_DETAILS")
@NamedQuery(name="LoginDetail.findAll", query="SELECT l FROM LoginDetail l")
public class LoginDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long accountno;

	@Column(name="LOGIN_PASSWORD")
	private String loginPassword;

	@Column(name="TRANSACTION_PASSWORD")
	private String transactionPassword;

	//bi-directional many-to-one association to Registernetbank
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private Registernetbank registernetbank;

	//bi-directional many-to-one association to Userdetails1
	@ManyToOne
	@JoinColumn(name="REFERENCEID")
	private Userdetails1 userdetails1;

	public LoginDetail() {
	}

	public long getAccountno() {
		return this.accountno;
	}

	public void setAccountno(long accountno) {
		this.accountno = accountno;
	}

	public String getLoginPassword() {
		return this.loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public String getTransactionPassword() {
		return this.transactionPassword;
	}

	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}

	public Registernetbank getRegisternetbank() {
		return this.registernetbank;
	}

	public void setRegisternetbank(Registernetbank registernetbank) {
		this.registernetbank = registernetbank;
	}

	public Userdetails1 getUserdetails1() {
		return this.userdetails1;
	}

	public void setUserdetails1(Userdetails1 userdetails1) {
		this.userdetails1 = userdetails1;
	}

}