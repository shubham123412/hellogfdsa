package com.entity.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the PAYEEDETAILS database table.
 * 
 */
@Entity
@Table(name="PAYEEDETAILS")
@NamedQuery(name="Payeedetail.findAll", query="SELECT p FROM Payeedetail p")
public class Payeedetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PayeedetailPK id;

	private String payeename;

	//bi-directional many-to-one association to FundTransfer1
	@OneToMany(mappedBy="payeedetail")
	private List<FundTransfer1> fundTransfer1s;

	//bi-directional many-to-one association to FundTransfer2
	@OneToMany(mappedBy="payeedetail")
	private List<FundTransfer2> fundTransfer2s;

	//bi-directional many-to-one association to Registernetbank
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private Registernetbank registernetbank;

	public Payeedetail() {
	}

	public PayeedetailPK getId() {
		return this.id;
	}

	public void setId(PayeedetailPK id) {
		this.id = id;
	}

	public String getPayeename() {
		return this.payeename;
	}

	public void setPayeename(String payeename) {
		this.payeename = payeename;
	}

	public List<FundTransfer1> getFundTransfer1s() {
		return this.fundTransfer1s;
	}

	public void setFundTransfer1s(List<FundTransfer1> fundTransfer1s) {
		this.fundTransfer1s = fundTransfer1s;
	}

	public FundTransfer1 addFundTransfer1(FundTransfer1 fundTransfer1) {
		getFundTransfer1s().add(fundTransfer1);
		fundTransfer1.setPayeedetail(this);

		return fundTransfer1;
	}

	public FundTransfer1 removeFundTransfer1(FundTransfer1 fundTransfer1) {
		getFundTransfer1s().remove(fundTransfer1);
		fundTransfer1.setPayeedetail(null);

		return fundTransfer1;
	}

	public List<FundTransfer2> getFundTransfer2s() {
		return this.fundTransfer2s;
	}

	public void setFundTransfer2s(List<FundTransfer2> fundTransfer2s) {
		this.fundTransfer2s = fundTransfer2s;
	}

	public FundTransfer2 addFundTransfer2(FundTransfer2 fundTransfer2) {
		getFundTransfer2s().add(fundTransfer2);
		fundTransfer2.setPayeedetail(this);

		return fundTransfer2;
	}

	public FundTransfer2 removeFundTransfer2(FundTransfer2 fundTransfer2) {
		getFundTransfer2s().remove(fundTransfer2);
		fundTransfer2.setPayeedetail(null);

		return fundTransfer2;
	}

	public Registernetbank getRegisternetbank() {
		return this.registernetbank;
	}

	public void setRegisternetbank(Registernetbank registernetbank) {
		this.registernetbank = registernetbank;
	}

}