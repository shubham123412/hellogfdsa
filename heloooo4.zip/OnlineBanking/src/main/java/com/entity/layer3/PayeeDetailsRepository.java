package com.entity.layer3;

public interface PayeeDetailsRepository {

}
