package com.entity.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.entity.layer2.FundTransfer1;
import com.entity.layer2.FundTransfer2;


@Repository
public class Fund_Transfer2RepoitoryImpl implements Fund_transfer2Repository {
	
	@PersistenceContext
	EntityManager entityManager;

	@Transactional
	public List<FundTransfer2> getAll() {
		
		String s="from FundTransfer2";
		Query query = entityManager.createQuery(s);
		List<FundTransfer2> Fund_Transfer2=query.getResultList();
		return Fund_Transfer2;
	
		//return null;
	}

//	@Override
	@Transactional
	public FundTransfer2 get(long Transactionid) {
	
		
		FundTransfer2 re = entityManager.find(FundTransfer2.class, Transactionid);
			//System.out.println(retailer.getRetailerAddress());
			//System.out.println(retailer.getRetailerEmail());
			
			return re;
		}
	

	
	
	

}
