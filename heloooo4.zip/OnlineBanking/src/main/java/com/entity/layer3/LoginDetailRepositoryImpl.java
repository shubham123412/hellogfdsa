package com.entity.layer3;

import java.util.List;

//import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.entity.layer2.LoginDetail;

@Repository
public class LoginDetailRepositoryImpl implements LoginDetailRepository {
	
	
	@PersistenceContext
	EntityManager entityManager;


//	@Override
//	public void get(LoginDetail login) {
//		// TODO Auto-generated method stub
		
//	}

	
		



		@Transactional
		public List<LoginDetail> get() {
			
			String s="from LoginDetail";
			
			Query query = entityManager.createQuery(s);
			
			List<LoginDetail> LoginDetails=query.getResultList();
			
			return LoginDetails;
		}
	

}
