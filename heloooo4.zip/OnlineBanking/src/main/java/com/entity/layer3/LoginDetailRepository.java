package com.entity.layer3;

import java.util.List;

import com.entity.layer2.LoginDetail;

public interface LoginDetailRepository {
	
		 
	//	 public void get(LoginDetail login );
		//	public void LoginDetail get1(long accountno);
		//	public void LoginDetail get1(String LoginPassword);
			
	//		public  void LoginDetail get(String TransactionPassword);
		public	List<LoginDetail> get();
		
		
		//	LoginDetail get(int USER_ID);
			
			
	}


