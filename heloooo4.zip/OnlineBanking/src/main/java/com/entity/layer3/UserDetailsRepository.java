package com.entity.layer3;

import com.entity.layer2.Userdetails1;

public interface UserDetailsRepository {

	public void adduser(Userdetails1 userdetails);
}
