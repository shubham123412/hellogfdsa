package com.entity.layer3;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.entity.layer2.Userdetails1;

@Repository
public class UserDetailsRepositoryImpl implements UserDetailsRepository {
	
	@PersistenceContext
	EntityManager entityManager;
	
@Transactional	
public void adduser(Userdetails1 userdetails) {
	
	entityManager.persist(userdetails);

}
}
