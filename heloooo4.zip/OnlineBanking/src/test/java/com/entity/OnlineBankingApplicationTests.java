package com.entity;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.entity.layer2.FundTransfer1;
import com.entity.layer2.FundTransfer2;
import com.entity.layer2.LoginDetail;
import com.entity.layer2.FundTransfer1;
import com.entity.layer2.Userdetails1;
import com.entity.layer2.Userdetails1;
import com.entity.layer3.Fund_transfer1Repository;
import com.entity.layer3.Fund_transfer2Repository;
import com.entity.layer3.LoginDetailRepository;
import com.entity.layer3.UserDetailsRepository;


import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootTest
class OnlineBankingApplicationTests {
	
//	@Autowired
	//LoginDetailRepository AK;
	
	@Autowired
	UserDetailsRepository b;
	@Autowired
	Fund_transfer1Repository a;
	
	@Autowired
	Fund_transfer2Repository c;
	
	@Autowired
	LoginDetailRepository d;
	
	
	@Test
	void testcase2()
	{
		List<FundTransfer2> get=c.getAll();
		for(FundTransfer2 fundtransfer2:get) {
		System.out.println("Fundtransfer2 "+fundtransfer2);
		}
	
	}
	
	@Test
	void contextLoads1() {
	//	List<Fund_Transfer1> get= new ArrayList<Fund_Transfer1>();
		List<FundTransfer2> get=c.getAll();
		
		for(FundTransfer2 as:get)
			
		{  System.out.println(as.getPayeedetail());
			System.out.println(as.getTransactionRemarks());
			System.out.println(as.getTransactionmode());
			System.out.println(as.getAmount());
			System.out.println(as.getTransactionid());
		
			//System.out.println(as);
		}
	}
	

	@Test
	void contextLoads() {
	//	List<Fund_Transfer1> get= new ArrayList<Fund_Transfer1>();
		List<FundTransfer1> get=a.getAll();
		
		for(FundTransfer1 as:get)
		{ 
			System.out.println(as.getTransactionid());
			System.out.println(as.getTransactionmode());
			System.out.println(as.getTransactionRemarks());
		
			System.out.println(as);
		}
	}
	
	@Test
	void testcase()
	{
		Userdetails1 user=new Userdetails1();
		//user.setApplicationDate(null);
		user.setFirstname("Atul");
		user.setLastname("George");
		user.setFathersname("Sanjeev");
		user.setDob(null);
		user.setMobileno("914588618023");
		user.setEMailId("atulgerge@gmail.com");
		user.setAdharcard("453948349500");
		user.setPresAddressline1("336/14-15 Khat Colony");
		user.setPresAddressline2("Nava Wadaj");
		user.setPresCity("Ahmedabad");
		user.setPresState("Gujarat");
		user.setPresZipcode(380013);
		user.setPermAddressline1("139/a Agarwal Estate");
		user.setPermAddressline2("S.v Road Jogeshwari (west)");
		user.setPermCity("Mumbai"); 
		user.setPermCity("Maharashtra");
	   user.setPermZipcode(400102);
		
		b.adduser(user);
		
	}
	
	@Test
	void contextLoads2() {
		long id = 111001;
	FundTransfer2 r = c.get(id);
	System.out.println(r.getAmount());
	System.out.println(r.getPayeedetail().getPayeename());
	System.out.println(r.getPayeedetail().getRegisternetbank().getAccountNo());
	}
	
	
	@Test
	void contextLoads3() {
		long id = 111001;
	FundTransfer1 r = a.get(id);
	System.out.println(r.getAmount());
	System.out.println(r.getPayeedetail().getRegisternetbank().getTransactionPassword());
	System.out.println(r.getPayeedetail().getRegisternetbank().getReferenceid());
    System.out.println(r.getTransactiontype());
    System.out.println(r.getPayeedetail().getId().getPayeeaccountno());
	System.out.println(r.getPayeedetail().getPayeename());
	System.out.println(r.getPayeedetail().getRegisternetbank().getAccountNo());
	}
	
	

	@Test
	void contextLoads4() {
	
		List<LoginDetail> get=d.get();
		for(LoginDetail as:get)
		{ 
			System.out.println(as.getAccountno());
		
//			//System.out.println(as);
		}
	}
}
